#!/usr/bin/env python3.8

from kivymd.app import MDApp
from kivy.lang import Builder
from kivy.config import Config
Config.set('kivy', 'keyboard_mode', 'systemandmulti')

import subprocess 

import rospy 
from std_msgs.msg import Int32
from std_msgs.msg import String

class aqavaders_interface(MDApp):
    pub = rospy.Publisher('/speed', Int32, queue_size=32)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        #kvPath = "/Home/ROV/topside_ws/src/gui/aquavaders_interface.kv"
        kvPath = "aquavaders_interface.kv"
        self.screen = Builder.load_file(kvPath)

    def build(self):
        return self.screen


    def thrusters(self, *args): 
        rospy.Subscriber("chatter", String, getmotors)

    def lunch(self, *args):
        #subprocess.run("bash Scripts/joy.sh", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        #subprocess.run("bash Scripts/joy.sh", shell=True)
        subprocess.run("bash script.sh", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    def speed100(self, *args):
        range = 100
        self.pub.publish(range)
        self.screen.ids.current_speed.text = 'Current range: 100'

    def speed200(self, *args):
        range = 200
        self.pub.publish(range)
        self.screen.ids.current_speed.text = 'Current range: 200'
    
    def speed300(self, *args):
        range = 300
        self.pub.publish(range)
        self.screen.ids.current_speed.text = 'Current range: 300'

    def joystick(self, *args):
        subprocess.run("bash joy.sh", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def fish(self, *args):
        mission = 'size - rana'

    def mapping(self, *args):
        mission = 'auto map - gohar'

    
if __name__ == "__main__":
    try:
        rospy.init_node('Aquavaders_GUI', anonymous=True)
        aqavaders_interface().run()
    except rospy.ROSInterruptException:
        pass 

    #try adding spin to loop forever
    
