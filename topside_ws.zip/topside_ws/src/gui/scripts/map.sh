#! /bin/bash 

source ~/ROV/Aquavaders/devel/setup.bash 
rosrun map_node mapm
