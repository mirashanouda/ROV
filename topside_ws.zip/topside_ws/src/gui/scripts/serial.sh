#! /bin/bash 

source ~/ROV/Aquavaders/devel/setup.bash 
rosrun serial_node serials
