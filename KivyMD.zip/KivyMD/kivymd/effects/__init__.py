"""
Effects
=======
"""
