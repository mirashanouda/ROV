"""
Toast for Android device
========================

.. image:: https://github.com/HeaTTheatR/KivyMD-data/raw/master/gallery/kivymddoc/toast.png
    :align: center

"""

__all__ = ("toast",)

from .androidtoast import toast
