from .rotatewidget import RotateWidget
