from .transition import MDFadeSlideTransition  # NOQA F401
