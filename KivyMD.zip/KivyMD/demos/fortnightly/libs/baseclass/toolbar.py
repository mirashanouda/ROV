from kivymd.theming import ThemableBehavior
from kivymd.uix.boxlayout import MDBoxLayout


class FortnightlyToolbar(ThemableBehavior, MDBoxLayout):
    pass
