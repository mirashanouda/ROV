from kivymd.theming import ThemableBehavior
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.tab import MDTabsBase


class CraneFlyScreen(ThemableBehavior, MDBoxLayout, MDTabsBase):
    pass
