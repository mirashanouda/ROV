from kivymd.theming import ThemableBehavior
from kivymd.uix.screen import MDScreen


class RallyBudgetsScreen(ThemableBehavior, MDScreen):
    pass
