from kivymd.uix.screen import MDScreen


class RallyAccountsScreen(MDScreen):
    pass
