from kivymd.theming import ThemableBehavior
from kivymd.uix.screen import MDScreen


class RallyBillsScreen(ThemableBehavior, MDScreen):
    pass
