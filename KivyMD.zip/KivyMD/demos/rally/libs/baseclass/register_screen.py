from kivymd.uix.screen import MDScreen


class RallyRegisterScreen(MDScreen):
    pass
