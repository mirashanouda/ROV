from kivymd.theming import ThemableBehavior
from kivymd.uix.screen import MDScreen


class ShrineRegisterScreen(ThemableBehavior, MDScreen):
    """Registration screen. Opens when the application starts."""
