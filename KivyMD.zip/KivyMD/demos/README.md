# KivyMD Demos

KivyMD has 5 demo applications.

- [Kitchen Sink](kitchen_sink). The main demo for KivyMD. It shows usage of all KivyMD widgets.

Material Studies:

- [Crane](crane).
- [Fortnightly](fortnightly).
- [Rally](rally).
- [Shrine](shrine).
